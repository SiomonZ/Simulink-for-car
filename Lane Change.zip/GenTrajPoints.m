function [lon_pos, lon_spd, lat_pos, lat_spd] = GenTrajPoints(actLats, actLatv, tgtLats)
    dT  = 0.01;
    cur_lateral_pos = actLats;
    cur_lateral_spd = actLatv;
    cur_lateral_acc = 0;
    des_lateral_pos = tgtLats;
    des_t = 6.0;
    lat_qp = quintic_polynomial(cur_lateral_pos, cur_lateral_spd, cur_lateral_acc, des_lateral_pos, 0.0, 0.0, des_t);
    
    cur_lon_pos = 0;
    cur_speed   = 10;
    des_spd     = 10;
    lon_qp = quartic_polynomial(cur_lon_pos, cur_speed, 0.0, des_spd, 0.0, des_t);
    t = dT*(1:600);
    t = t';
    lat_qp = lat_qp(end:-1:1); %��� polyval����Ҫ��ϵ���ĳɡ�����˳��
    lon_qp = lon_qp(end:-1:1);
    lon_pos = polyval(lon_qp, t);
    lon_spd = polyval([4,3,2,1].*lon_qp(1:end-1), t);
    lat_pos = polyval(lat_qp, t);
    lat_spd = polyval([5,4,3,2,1].*lat_qp(1:end-1), t);
end

function lat_qp = quintic_polynomial(xs, vxs, axs, xe, vxe, axe, T)
% 5�ζ���ʽ���
    a0 = xs;
    a1 = vxs;
    a2 = axs/2;
    A = [T^3,   T^4,   T^5
         3*T^2, 4*T^3, 5*T^4
         6*T    12*T^2,20*T^3];
    b = [xe-a0-a1*T-a2*T^2
         vxe-a1-2*a2*T
         axe-2*a2];
    x = A\b;
    lat_qp = [a0, a1, a2, x(1),x(2),x(3)];
end
function lat_qp = quartic_polynomial(xs, vxs, axs, vxe, axe, T)
% 4�ζ���ʽ���
    a0 = xs;
    a1 = vxs;
    a2 = axs/2;
    A = [3*T^2, 4*T^3;
         6*T    12*T^2,];
    b = [vxe-a1-2*a2*T
         axe-2*a2];
    x = A\b;
    lat_qp = [a0, a1, a2, x(1),x(2)];
end