classdef MPCControl < matlab.System& matlab.system.mixin.Propagates
    % Untitled2 Add summary here
    %
    % This template includes the minimum set of functions required
    % to define a System object with discrete state.

    % Public, tunable properties
    properties
        
    end

    properties(DiscreteState)

    end

    % Pre-computed constants
    properties(Access = private)
        m_steer = 0;
        m_acc = 0;
    end

    methods(Access = protected)
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
        end

         function [acc, steer] = ...
                  stepImpl(obj, controlFlag, traj_ref, veh_state, t)   
                  dT = 0.01;
                  %  traj_ref
                  %       x
                  %       y
                  %       phi
                  %       curvature
                  %       v
                  %       t
                  %       s
                  disp('*************MPCControl******Loop***************');
                  disp(['time is ',num2str(t)])
                  disp(controlFlag)
                  if(controlFlag > 0)
                      VehConf.m  = 1217.2; %会自动创建一个结构体变量 VehConf
                      VehConf.Cf = 40000;
                      VehConf.Cr = 40000;
                      VehConf.Lf = 1.165;
                      VehConf.Lr = 1.165;
                      VehConf.Iz = 1020;
                      selectIdx = 1;
                      for i = 1:size(traj_ref,1)
                        if abs(t - traj_ref(i,6)) <= 0.0011
                            selectIdx = i;
                            break;
                        end
                      end
                      vDes    = traj_ref(selectIdx,5);
                      phiDes  = traj_ref(selectIdx,3);
                      kDes = traj_ref(selectIdx,4);
                      dphiDes = vDes*kDes;
                      xTarget = traj_ref(selectIdx,1);
                      yTarget = traj_ref(selectIdx,2);
                      dxTarget = veh_state.xpos - xTarget;
                      dyTarget = veh_state.ypos - yTarget;
                      disp('*************MPCControl*******disp**************');
                      disp(t)
                      disp(selectIdx)
                      disp(traj_ref(1,6))
                      disp(traj_ref(2,6))
                      disp(traj_ref(end,6))
                      disp(traj_ref(selectIdx, 6))
                      disp(xTarget);
                      disp(yTarget);
                      disp(veh_state.xpos)
                      disp(veh_state.ypos)
                      heading_error      = veh_state.yaw - phiDes;
                      heading_error_rate = veh_state.yawrate - dphiDes;
                      lateral_error      = dyTarget*cos(phiDes) - dxTarget*sin(phiDes);
                      lateral_error_rate = veh_state.vact*sin(heading_error);
                      kParam = 1;
                      speed_error =  vDes - veh_state.vact*cos(heading_error)/kParam;
                      station_error = -(dxTarget*cos(phiDes) + dyTarget*sin(phiDes));
                      ErrState = [lateral_error;lateral_error_rate;heading_error;heading_error_rate; station_error; speed_error];
                      
%                       disp('***************MPCControl*****ErrState**************');
%                       disp(ErrState);
                      [A, B, C] = GetMPCControlMatrix(VehConf, veh_state.vact);
                      Ad = eye(6) + dT*A;
                      Bd = dT*B;
                      Cd = dT*C*heading_error_rate;
                      u = solveMPC(Ad,Bd,Cd,ErrState,zeros(6,1));
                      obj.m_steer = u(1);
                      obj.m_acc   = u(2);
                  end
                  steer = obj.m_steer;
                  acc = obj.m_acc;
                   
         end

        function resetImpl(obj)
            % Initialize / reset discrete-state properties
        end
        
        function [acc, steer] = getOutputSizeImpl(~)
            % Return size for each output port
            acc = 1;
            steer = 1;
        end
        
        %------------------------------------------------------------------
        function [acc, steer] = getOutputDataTypeImpl(~)
            % Return data type for each output port
            acc    = 'double';
            steer     = 'double';
        end
        
        %------------------------------------------------------------------
        function [acc, steer] = isOutputComplexImpl(~)
            % Return true for each output port with complex data
            acc        = false;
            steer    = false;
        end
        
        %------------------------------------------------------------------
        function [acc, steer] = isOutputFixedSizeImpl(~)
            % Return true for each output port with fixed size
            acc        = true;
            steer    = true;
        end
        
    end
end
