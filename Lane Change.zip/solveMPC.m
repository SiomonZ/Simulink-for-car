function  u = sloveMPC(A,B,C,X,Xref)
% 求解MPC问题的函�?
% 输入
% A 模型A矩阵
% B 模型B矩阵
% C 模型C矩阵
% X 状�?�变�?
% XRef 状�?�变量参考�??
% 这里状�?�空间模型是差分模型，因此状态变量参考�?�为0
% 算法�?
% 输入序列是决策变量�??
% 根据模型，从输入与序列能够计算出几个步长后的状�?��?�（用决策变量表示）
% 从�?�能够用决策变量表示目标函数和约束条�?
% 求解二次规划就能够得出期望的决策变量，也就是输入序列
    Q = [5  0    0  0    0    0
         0  1    0  0    0    0
         0  0    5  0    0    0
         0  0    0  1    0    0
         0  0    0  0    1    0
         0  0    0  0    0    1];
    R = [1  0
         0  1];
    As  = A;
    Ks  = B;
    Ks1 = B;
    Cs  = C;
    Cs1 = C;
    Qs  = Q;
    Rs  = R;
    N = 3;
    Xrefs = Xref;
    for i = 1:N
        As  = [A, A*As];
        Ks1 = [A*Ks1, B];
        Ks  = [Ks, zeros(size(Ks,1),size(B,2));Ks1];
        Cs1 = [C+A*Cs1];
        Cs  = [Cs; Cs1];
        Rs  = blkdiag(Rs, R);
        Qs  = blkdiag(Qs, Q);
        Xrefs = [Xrefs;Xref];
    end
    M = (As.')*X;
    H = (Ks.')*Qs*Ks + Rs;
    T = (M+Cs-Xrefs);
    G = (Ks.')*Qs*T;
    lb = [-1; -2];
    ub = [1;   2];
    lb = repmat(lb, 1, N+1);
    ub = repmat(ub, 1, N+1);
    z1 = quadprog(H,G, [],[],[],[],lb,ub);
    % 无约束MPC的解析解
%     z2  = -H\G;
    u = z1(1:2);
end