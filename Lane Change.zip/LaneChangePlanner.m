classdef LaneChangePlanner < matlab.System
    % Untitled Add summary here
    %
    % This template includes the minimum set of functions required
    % to define a System object with discrete state.

    % Public, tunable properties
    properties
    end

    properties(DiscreteState)

    end

    % Pre-computed constants
    properties(Access = private)
        m_traj = zeros(600,7);
    end

    methods(Access = protected)
        function setupImpl(obj)
            % Perform one-time calculations, such as computing constants
        end

        function trajRet = stepImpl(obj,replanflag,t0,lanenum)
            % Implement algorithm. Calculate y as a function of input u and
            % discrete states.
            if(replanflag == 1)
                s0 = 0;
                actLats = 0;
                actLatv = 0.0;
                selectIdx = 1;
                if t0 > 0.1
                    for i = 1:size(obj.m_traj,1)
                        if abs(t0 - obj.m_traj(i,6)) <= 0.0001
                            selectIdx = i;
                            break;
                        end
                    end
                    s0 = obj.m_traj(selectIdx, 7);
                    tp_x = obj.m_traj(selectIdx, 1);
                    tp_y = obj.m_traj(selectIdx, 2);
                    tp_phi = obj.m_traj(selectIdx, 3);
                    tp_v = obj.m_traj(selectIdx, 5);
                    pref_x = s0;
                    pref_y = 0;
                    pref_phi = 0;
                    dx = tp_x - pref_x;
                    dy = tp_y - pref_y;
                    actLats = dy* cos(pref_phi)-dx*sin(pref_phi);
                    actLatv = tp_v* (sin(tp_phi)* cos(pref_phi)-cos(tp_phi)*sin(pref_phi));
                end
                tgtLatss = [4.0, 0.0, -4.0];
                tgtLats = tgtLatss(lanenum + 1);
                disFacTable_X = [-0.01 0.2, 0.3, 0.5, 1.0, 1.8, 2.0,4.0 4.01];
                disFacTable_Y = [0.0 0.0, 0.1, 0.4, 0.6, 0.8, 1.0,1.0 1.0];
                fac = interp1(disFacTable_X,disFacTable_Y,abs(tgtLats - actLats));
                [lon_pos, lon_spd, lat_pos, lat_spd] = GenTrajPoints(actLats, actLatv*fac, tgtLats);
%                 disp('***********LaneChangePlanner*************')
%                 disp(fac)
%                 disp(tgtLats)
%                 disp(actLats)
                t = (1:600)*0.01;
                s = s0 + lon_pos;
                v = sqrt(lon_spd.^2 + lat_spd.^2);
                phi = atan(lat_spd./lon_spd);
                pref_x = s;
                pref_y = s*0;
                pref.phi = s*0;
                x = pref_x + lat_pos.*cos(pref.phi + pi/2);
                y = pref_y + lat_pos.*sin(pref.phi + pi/2);
                obj.m_traj(:,1) = x;
                obj.m_traj(:,2) = y;
                disp('replan')
                disp(y);
                obj.m_traj(:,3) = phi;
                obj.m_traj(:,4) = phi*0;
                obj.m_traj(:,5) = v;
                obj.m_traj(:,6) = t + t0;
                obj.m_traj(:,7) = s;
                len = size(obj.m_traj,1);
                obj.m_traj(1,  4) = 0;
                obj.m_traj(len,4) = 0;
                for i = 2:(len-1)
                    a = obj.m_traj(i-1, 1:2);
                    b = obj.m_traj(i  , 1:2);
                    c = obj.m_traj(i+1, 1:2);
                    obj.m_traj(i,  4) = getCurvature(a,b,c);
                end
            end      
            trajRet = obj.m_traj;
        end

        function resetImpl(obj)
            % Initialize / reset discrete-state properties
        end
        
        function trajRet = getOutputSizeImpl(~)
            % Return size for each output port
            trajRet = [600,7];
        end
        
        %------------------------------------------------------------------
        function trajRet = getOutputDataTypeImpl(obj)
            % Return data type for each output port
            trajRet    = 'double';
        end
        
        %------------------------------------------------------------------
        function trajRet = isOutputComplexImpl(~)
            % Return true for each output port with complex data
            trajRet        = false;
        end
        
        %------------------------------------------------------------------
        function trajRet = isOutputFixedSizeImpl(~)
            % Return true for each output port with fixed size
            trajRet        = true;
        end
    end
end
